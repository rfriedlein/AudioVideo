#
# __init__.py
#
# Copyright (c) 2011 Red Hat, Inc.
# 
"""
rhn - A collection of modules used by Red Hat Network
"""

